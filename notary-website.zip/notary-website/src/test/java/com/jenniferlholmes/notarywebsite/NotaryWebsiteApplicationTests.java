package com.jenniferlholmes.notarywebsite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NotaryWebsiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
