package com.jenniferlholmes.notarywebsite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NotaryWebsiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(NotaryWebsiteApplication.class, args);
	}

}
